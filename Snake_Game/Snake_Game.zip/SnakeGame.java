class SnakeGame extends GameFrame{

    public static void main(String[] args) {
        new GamaLogic(600,600);
        new GameFrame();
    }
}